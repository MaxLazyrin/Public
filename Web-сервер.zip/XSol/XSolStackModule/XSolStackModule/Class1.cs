﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using WebServer;

namespace XSolStackModule
{
    public static class StackAPI
    {
        static string location = GetLocation();
        static string GetLocation()
        {
            string loc = Assembly.GetExecutingAssembly().Location;
            for (int i = loc.Length - 1; i >= 0; i--)
            {
                if (loc[i] == '\\') return loc.Substring(0, i);
            }
            return loc;
        }

        public static bool OnPing(string arg, HTTPReqest req, ScktIO io)
        {
            HTTPResponse rsp = new HTTPResponse();
            rsp.version = "HTTP/1.1";
            rsp.stateCode = "200";
            rsp.stateComment = "OK";
            rsp.Send(io);
            return true;
        }

        static List<string> stack = new List<string>();
        public static bool ReqHandler(string arg, HTTPReqest req, ScktIO io)
        {
            if (req.url == "/Push")
            {
                lock (stack) stack.Add(((List<string>)req.headers["ARG0:"])[0]);
                HTTPResponse rsp = new HTTPResponse();
                rsp.version = "HTTP/1.1";
                rsp.stateCode = "200";
                rsp.stateComment = "OK";
                rsp.Send(io);
                return true;
            }
            else if (req.url == "/Pop")
            {
                string r;
                lock (stack)
                {
                    if (stack.Count == 0)
                    {
                        HTTPResponse lrsp = new HTTPResponse();
                        lrsp.version = "HTTP/1.1";
                        lrsp.stateCode = "405";
                        lrsp.stateComment = "Stack is empty";
                        lrsp.Send(io);
                        return true;
                    }
                    r = stack[stack.Count - 1];
                    stack.RemoveAt(stack.Count - 1);
                }
                HTTPResponse rsp = new HTTPResponse();
                rsp.version = "HTTP/1.1";
                rsp.stateCode = "200";
                rsp.stateComment = "OK";
                rsp.headers.Add("Content-Length:", r.Length.ToString());
                rsp.headers.Add("Content-Type:", "text/plain");
                rsp.content = new MemoryStream(Encoding.ASCII.GetBytes(r));
                rsp.Send(io);
                return true;
            }
            else if (req.url == "/Peek")
            {
                string r;
                lock (stack)
                {
                    if (stack.Count == 0)
                    {
                        HTTPResponse lrsp = new HTTPResponse();
                        lrsp.version = "HTTP/1.1";
                        lrsp.stateCode = "405";
                        lrsp.stateComment = "Stack is empty";
                        lrsp.Send(io);
                        return true;
                    }
                    r = stack[stack.Count - 1];
                }
                HTTPResponse rsp = new HTTPResponse();
                rsp.version = "HTTP/1.1";
                rsp.stateCode = "200";
                rsp.stateComment = "OK";
                rsp.headers.Add("Content-Length:", r.Length.ToString());
                rsp.headers.Add("Content-Type:", "text/plain");
                rsp.content = new MemoryStream(Encoding.ASCII.GetBytes(r));
                rsp.Send(io);
                return true;
            }
            else if (req.url == "/Size")
            {
                string r;
                lock (stack) r = stack.Count.ToString();
                HTTPResponse rsp = new HTTPResponse();
                rsp.version = "HTTP/1.1";
                rsp.stateCode = "200";
                rsp.stateComment = "OK";
                rsp.headers.Add("Content-Length:", r.Length.ToString());
                rsp.headers.Add("Content-Type:", "text/plain");
                rsp.content = new MemoryStream(Encoding.ASCII.GetBytes(r));
                rsp.Send(io);
                return true;
            }
            return false;
        }
    }
}
