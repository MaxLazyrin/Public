﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WebServer
{
    public static class Settings
    {
        public static Hashtable ext_type = new Hashtable();
        public static int frame_length = 655360;
        public static string default_name = "index.html";
        public static int keepAliveTime = 60000;
        public static int desiredPort = 80;
        public static bool searchFreePort = true;

        public static void Load()
        {
            if (File.Exists("settings\\MIME.txt"))
            {
                string[] arr = File.ReadAllLines("settings\\MIME.txt");
                foreach (string s in arr)
                {
                    string[] a = s.Split(' ');
                    ext_type.Add(a[0], a[1]);
                }
            }
            else
            {
                ext_type.Add("htm", "text/html");
                ext_type.Add("html", "text/html");
                ext_type.Add("js", "text/javascript");
                ext_type.Add("txt", "text/plain");
                ext_type.Add("xml", "text/xml");
                ext_type.Add("gif", "image/gif");
                ext_type.Add("jpeg", "image/jpeg");
                ext_type.Add("jpg", "image/jpeg");
                ext_type.Add("png", "image/png");
                ext_type.Add("json", "text/plain");
            }
            if (File.Exists("other.txt"))
            {
                string[] arr = File.ReadAllLines("other.txt");
                frame_length = int.Parse(arr[0]);
                default_name = arr[1];
                keepAliveTime = int.Parse(arr[2]);
                desiredPort = int.Parse(arr[3]);
                searchFreePort = (arr[4] == "true") ? true : false;
            }
        }
    }

    public class ScktIO
    {
        public Socket sckt;
        public byte[] avail = new byte[1024];
        public int nextFrame = 1024;
        public int len = 0;
        public int pos = 0;
        public int Available { get { int r = len - pos; if (r < 0) r = 0; r += sckt.Available; return r; } }

        void ReadNext()
        {
            int rd = avail.Length;
            if (nextFrame != rd)
            {
                Array.Resize(ref avail, nextFrame);
                rd = nextFrame;
            }
            int av = sckt.Available;
            if (av < rd) rd = av;
            int recv = sckt.Receive(avail, rd, SocketFlags.None);
            len = recv;
        }

        public byte NextByte()
        {
            if (len - pos > 0)
            {
                pos++;
                return avail[pos - 1];
            }
            else
            {
                ReadNext();
                pos = 1;
                return avail[0];
            }
        }

        public void Read(byte[] buf, int pos, int count)
        {
            loo:;
            int av = this.len - this.pos;
            if (av > 0)
            {
                if (count < av) av = count;
                for (int i = 0; i < av; i++)
                {
                    buf[pos++] = avail[this.pos++];
                    count--;
                }
            }
            if (count > 0)
            {
                ReadNext();
                goto loo;
            }
        }
    }

    public class HTTPReqest
    {
        public string argline;
        public string method;
        public string url;
        public string version;
        public Hashtable headers = new Hashtable();
        public byte[] content = null;

        static string Next(ScktIO sckt)
        {
            List<byte> lst = new List<byte>();
            while (sckt.Available > 0)
            {
                byte b = sckt.NextByte();
                if (b == 32)
                {
                    if (lst.Count == 0) continue;
                    break;
                }
                else if (b == 13 || b == 10)
                {
                    if (lst.Count == 0)
                    {
                        lst.Add(b);
                        byte nx = sckt.NextByte();
                        if (nx != 10) sckt.pos--;
                        else lst.Add(nx);
                        break;
                    }
                    else
                    {
                        sckt.pos--;
                        break;
                    }
                }
                lst.Add(b);
            }
            return Encoding.ASCII.GetString(lst.ToArray());
        }

        public static HTTPReqest Load(ScktIO sckt)
        {
            HTTPReqest req = new HTTPReqest();

            req.method = Next(sckt);
            req.url = Next(sckt);
            for (int i = 0; i < req.url.Length; i++)
            {
                if (req.url[i] == '?')
                {
                    req.argline = req.argline.Substring(i + 1);
                    req.url = req.url.Substring(0, i);
                    break;
                }
            }

            req.version = Next(sckt);
            string nx = Next(sckt);
            nx = Next(sckt);
            while (nx != "\r\n" && nx != "\n")
            {
                string key = nx;
                List<string> vals = new List<string>();
                nx = Next(sckt);
                while (nx != "\r\n" && nx != "\n")
                {
                    vals.Add(nx);
                    nx = Next(sckt);
                }
                req.headers.Add(key, vals);
                nx = Next(sckt);
            }

            if (req.headers.Contains("Content-Length:"))
            {
                List<string> lst = (List<string>)req.headers["Content-Length:"];
                int cnt = (int.Parse(lst[0]));
                sckt.nextFrame = cnt;
                req.content = new byte[cnt];
                sckt.Read(req.content, 0, cnt);
            }

            return req;
        }
    }

    public static class Program
    {
        static Socket srvSocket;
        static void OpenSocket()
        {
            srvSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                srvSocket.Bind(new IPEndPoint(IPAddress.Any, Settings.desiredPort));
                Console.WriteLine("Порт: " + Settings.desiredPort.ToString());
                return;
            }
            catch
            {
                if (Settings.searchFreePort == false)
                {
                    throw new Exception("Не удалось занять желаемый порт");
                }
            }
            int port = 80;
            loo:;
            try
            {
                srvSocket.Bind(new IPEndPoint(IPAddress.Any, port));
            }
            catch
            {
                if (port == 80) port = 10000;
                else port++;
                goto loo;
            }
            Console.WriteLine("Порт: " + port.ToString());
        }

        public static void InstancesMod(int count)
        {
            lock (syncObj) handlersInstances += count;
        }
        
        public static object syncObj = new object();
        public static int handlersInstances = 0;
        static void HandlerThread(object state)
        {
            Socket cli = (Socket)state;
            ScktIO rd = new ScktIO();
            rd.sckt = cli;
            try
            {
                loo:;
                int sli = 0;
                int sliMax = Settings.keepAliveTime / 100 + 1;
                while (cli.Available == 0) { if (exit || sli >= sliMax) goto ex; Thread.Sleep(100); sli++; }
                HTTPReqest req = HTTPReqest.Load(rd);

                ReqHandler.Handle(req, rd);

                if (exit == false) goto loo;
            }
            catch (Exception ex) { }
            ex:;
            try { cli.Close(); } catch { }
            lock (syncObj) handlersInstances--;
        }

        static void AcceptThread(object state)
        {
            try
            {
                List<Socket> handle = (List<Socket>)state;
                loo:;
                Socket s = srvSocket.Accept();
                lock (handle) handle.Add(s);
                goto loo;
            }
            catch { return; }
        }

        public static bool exit = false;
        public static bool exited = false;
        static Thread thread;
        static void ThreadProc()
        {
            List<Socket> handle = new List<Socket>();
            Thread accThr = new Thread(AcceptThread);
            accThr.Start(handle);
            while (exit == false)
            {
                lock (handle)
                {
                    lock (syncObj) handlersInstances += handle.Count;
                    while (handle.Count > 0)
                    {
                        Socket sckt = handle[0];
                        handle.RemoveAt(0);
                        new Thread(HandlerThread).Start(sckt);
                    }
                }
                Thread.Sleep(100);
            }
            srvSocket.Close();
            while (handlersInstances > 0) Thread.Sleep(10);
            exited = true;
        }

        static void Main(string[] args)
        {
            Settings.Load();
            Console.WriteLine("Открытие сокета...");
            OpenSocket();
            Console.WriteLine("Загрузка внешних модулей...");
            ExternalModules.Load();
            srvSocket.Listen(10);
            Console.WriteLine("Сервер переведен в режим обработки запросов");
            thread = new Thread(ThreadProc);
            thread.Start();
            Console.WriteLine("Для завершения работы сервера нажмите любую клавишу...");
            while (Console.KeyAvailable == false) { if (exit) break; Thread.Sleep(100); }
            Console.WriteLine("Остановка сервера...");
            exit = true;
            while (exited == false) Thread.Sleep(10);
        }
    }
}
