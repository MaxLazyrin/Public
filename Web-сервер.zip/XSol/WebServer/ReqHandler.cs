﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace WebServer
{
    public delegate bool ExternalHandler(string arg, HTTPReqest req, ScktIO io);
    public static class ExternalModules
    {
        public static Hashtable handlers = new Hashtable();

        public static bool HandleRequest(HTTPReqest request, ScktIO io)
        {
            Hashtable reqHt = (Hashtable)handlers[request.method];
            if (reqHt == null) return false;
            List<Tuple<ExternalHandler, string>> urlLst = (List<Tuple<ExternalHandler, string>>)reqHt[request.url];
            if (urlLst == null) return false;
            for (int i = 0; i < urlLst.Count; i++)
            {
                if (urlLst[i].Item1(urlLst[i].Item2, request, io)) return true;
            }
            return false;
        }

        public static void AddHandler(string reqMethod, string url, string arg, ExternalHandler handler)
        {
            Hashtable reqHt = (Hashtable)handlers[reqMethod];
            if (reqHt == null)
            {
                reqHt = new Hashtable();
                handlers.Add(reqMethod, reqHt);
            }
            List<Tuple<ExternalHandler, string>> urlLst = (List<Tuple<ExternalHandler, string>>)reqHt[url];
            if (urlLst == null)
            {
                urlLst = new List<Tuple<ExternalHandler, string>>();
                reqHt.Add(url, urlLst);
            }
            urlLst.Add(new Tuple<ExternalHandler, string>(handler, arg));
        }

        public static void Load()
        {
            if (File.Exists("modules\\handlers.txt") == false) return;
            string[] arr = File.ReadAllLines("modules\\handlers.txt");
            if (arr.Length == 0) return;
            int rd = 0;
            while (arr[rd] == "")
            {
                rd++;
                if (rd >= arr.Length) return;
            }
            string asm = arr[rd];
            Assembly lasm = null;
            rd++;
            while (arr[rd] != "{") rd++;
            rd++;
            while (arr[rd] != "}")
            {
                if (arr[rd] == "") { rd++; continue; }
                string tp = arr[rd];
                Type ltp = null;
                rd++;
                while (arr[rd] != "{") rd++;
                rd++;
                while (arr[rd] != "}")
                {
                    if (arr[rd] == "") { rd++; continue; }
                    string method = arr[rd];
                    rd++;
                    while (arr[rd] != "{") rd++;
                    rd++;
                    while (arr[rd] != "}")
                    {
                        if (arr[rd] == "") { rd++; continue; }

                        string reqMethod = arr[rd];
                        string url = arr[rd + 1];
                        string arg = arr[rd + 2];
                        rd += 2;

                        if (lasm == null) lasm = Assembly.LoadFrom(asm);
                        if (ltp == null) ltp = lasm.GetType(tp);
                        MethodInfo lmethod = ltp.GetMethod(method, new Type[] { typeof(string), typeof(HTTPReqest), typeof(ScktIO) });
                        AddHandler(reqMethod, url, arg, (ExternalHandler)Delegate.CreateDelegate(typeof(ExternalHandler), lmethod));

                        rd++;
                    }
                    rd++;
                }
                rd++;
            }
        }
    }

    public class HTTPResponse
    {
        public string version;
        public string stateCode;
        public string stateComment;
        public Hashtable headers = new Hashtable();
        public Stream content;

        public void Send(ScktIO sckt)
        {
            string str = version + " " + stateCode + " " + stateComment + "\r\n";
            foreach (string k in headers.Keys)
            {
                string v = (string)headers[k];
                str += k + " " + v + "\r\n";
            }
            str += "\r\n";
            byte[] arr = Encoding.ASCII.GetBytes(str);
            sckt.sckt.Send(arr);
            if (content != null)
            {
                byte[] buf = new byte[Settings.frame_length];
                while (content.Length - content.Position > 0)
                {
                    int rd = buf.Length;
                    if (content.Length < (long)rd) rd = (int)content.Length;
                    content.Read(buf, 0, rd);
                    sckt.sckt.Send(buf, 0, rd, System.Net.Sockets.SocketFlags.None);
                }
            }
            content.Close();
        }
    }

    public static class LUtils
    {
        public static string UrlToFilename(string url)
        {
            string r = "";
            for (int i = 0; i < url.Length; i++)
            {
                if (url[i] == '/') r += '\\';
                else r += url[i];
            }
            return r;
        }

        public static string GetExt(string fname)
        {
            string r = "";
            for (int i = fname.Length - 1; i >= 0; i--)
            {
                if (fname[i] == '.')
                {
                    return r;
                }
                else if (fname[i] == '\\') return "";
                else r = fname[i] + r;
            }
            return "";
        }
    }

    static class ReqHandler
    {
        public static void Handle(HTTPReqest req, ScktIO sckt)
        {
            if (ExternalModules.HandleRequest(req, sckt)) return;
            if (req.method == "GET")
            {
                HandleGet(req, sckt);
                return;
            }

            HTTPResponse rsp = new HTTPResponse();
            rsp.version = "HTTP/1.1";
            rsp.stateCode = "501";
            rsp.stateComment = "Not supported";
            rsp.Send(sckt);
        }        

        static void LdFile(string fname, HTTPResponse rsp)
        {
            string ext = LUtils.GetExt(fname);
            string ctype = (string)Settings.ext_type[ext];
            if (ctype != null) rsp.headers.Add("Content-Type:", ctype);
            FileInfo fi = new FileInfo(fname);
            rsp.headers.Add("Content-Length:", fi.Length.ToString());
            rsp.content = new FileStream(fname, FileMode.Open, FileAccess.Read, FileShare.Read);
        }

        static void HandleGet(HTTPReqest req, ScktIO sckt)
        {
            string fname = LUtils.UrlToFilename(req.url);
            if (fname[fname.Length - 1] == '\\') fname += Settings.default_name;
            if (File.Exists("root" + fname))
            {
                HTTPResponse rsp = new HTTPResponse();
                rsp.version = "HTTP/1.1";
                rsp.stateCode = "200";
                rsp.stateComment = "OK";
                LdFile("root" + fname, rsp);
                rsp.Send(sckt);
            }
            else
            {
                HTTPResponse rsp = new HTTPResponse();
                rsp.version = "HTTP/1.1";
                rsp.stateCode = "404";
                rsp.stateComment = "Not found";
                rsp.Send(sckt);
            }
        }
    }
}
