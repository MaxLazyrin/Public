﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SquareCalc
{
    public static class Square
    {
        /// <summary>
        /// Функция вычисления площади круга по радиусу
        /// </summary>
        /// <param name="radius">Радиус круга</param>
        /// <returns>Площадь круга</returns>
        public static double Circle(double radius)
        {
            return Math.PI * radius * radius;
        }

        /// <summary>
        /// Функция вычисления площади круга
        /// </summary>
        /// <param name="radius">Радиус круга</param>
        /// <returns>Площадь круга</returns>
        public static double UndefSquare(double radius)
        {
            return Circle(radius);
        }

        /// <summary>
        /// Функция вычисления площади треугольника по трем сторонам
        /// </summary>
        /// <param name="l0">Длина стороны A</param>
        /// <param name="l1">Длина стороны B</param>
        /// <param name="l2">Длина Стороны C</param>
        /// <returns>Площадь треугольника</returns>
        public static double Triangle(double l0, double l1, double l2)
        {
            double p = (l0 + l1 + l2) / 2;
            return Math.Sqrt(p * (p - l0) * (p - l1) * (p - l2));
        }

        /// <summary>
        /// Функция вычисления площади треугольника по трем сторонам
        /// </summary>
        /// <param name="l0">Длина стороны A</param>
        /// <param name="l1">Длина стороны B</param>
        /// <param name="l2">Длина Стороны C</param>
        /// <returns>Площадь треугольника</returns>
        public static double UndefSquare(double l0, double l1, double l2)
        {
            return Triangle(l0, l1, l2);
        }

        /// <summary>
        /// Функция проверки треугольника на наличие прямого угла по трем сторонам
        /// </summary>
        /// <param name="l0">Длина стороны A</param>
        /// <param name="l1">Длина стороны B</param>
        /// <param name="l2">Длина Стороны C</param>
        /// <returns>True - содержит прямой угол, False - не содержит</returns>
        public static bool IsTriangleRectangular(double l0, double l1, double l2)
        {
            List<double> lst = new List<double>();
            lst.Add(l0);
            lst.Add(l1);
            lst.Add(l2);
            int ind = 0;
            double max = lst[0];
            for (int i = 1; i < lst.Count; i++) if (lst[i] > max)
                {
                    max = lst[i];
                    ind = i;
                }
            lst.RemoveAt(ind);
            return max * max == lst[0] * lst[0] + lst[1] * lst[1];
        }
    }
}
