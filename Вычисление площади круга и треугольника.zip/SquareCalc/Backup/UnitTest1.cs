﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SquareCalc;

namespace SquareCalcUnitTest
{
    [TestClass]
    public class SquareCalcUnitTest1
    {
        [TestMethod]
        public void TestCircle()
        {
            Assert.AreEqual(Square.Circle(10), 314.1593, 0.05, "Circle error (10)");
            Assert.AreEqual(Square.Circle(0), 0, "Circle error (0)");
            Assert.AreEqual(Square.UndefSquare(1), Math.PI, "Undefined cicrle error (1)");
        }

        [TestMethod]
        public void TestTriangle()
        {
            Assert.AreEqual(Square.Triangle(1, 1, 1), 0.4330127018922193, 0.0005, "Triangle error (1, 1, 1)");
            Assert.AreEqual(Square.Triangle(1, 2, 1), 0, 0, "Triangle error (1, 2, 1)");
            Assert.AreEqual(Square.UndefSquare(2, 4, 3), 2.9047375096555625, 0.0005, "Undefined triangle error (2, 4, 3)");
        }

        [TestMethod]
        public void TestRectangular()
        {
            Assert.AreEqual(Square.IsTriangleRectangular(3, 4, 5), true, "Rectangular triangle error (3, 4, 5)");
            Assert.AreEqual(Square.IsTriangleRectangular(5, 4, 3), true, "Rectangular triangle error (5, 4, 3)");
            Assert.AreEqual(Square.IsTriangleRectangular(3, 5, 4), true, "Rectangular triangle error (3, 5, 4)");
            Assert.AreEqual(Square.IsTriangleRectangular(3, 3, 3), false, "Rectangular triangle error (3, 3, 3)");
        }
    }
}
